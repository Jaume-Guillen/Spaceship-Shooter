#include "Menu.h"
#include "Game.h"

Menu::Menu()
{
	mesh = new Mesh();
	mesh->vertices.resize(4);
	mesh->uvs.resize(4);

	mesh->vertices[0] = Vector3(-1, -1, 0); mesh->uvs[0] = Vector2(0, 0);
	mesh->vertices[1] = Vector3(1, -1, 0); mesh->uvs[1] = Vector2(1, 0);
	mesh->vertices[2] = Vector3(1, 1, 0); mesh->uvs[2] = Vector2(1, 1);
	mesh->vertices[3] = Vector3(-1, 1, 0); mesh->uvs[3] = Vector2(0, 1);

	mesh->indices.resize(6);
	mesh->indices[0] = 0; mesh->indices[1] = 1; mesh->indices[2] = 2;
	mesh->indices[3] = 0; mesh->indices[4] = 2; mesh->indices[5] = 3;

	mesh->genBuffers();

	current_entry = 0;
}

void Menu::render() {

	Game* g = Game::instance;

	//crear MVP
	//crear normal matrix

	//crear una luz temporary

	//subir uniforms al shader

	g->resource_manager->getShader("menu")->enable();
	//shader->setUniform3("u_cam_pos", g->scene->camera->eye.x, g->scene->camera->eye.y, g->scene->camera->eye.z);
	shader->setTexture("u_texture_diffuse", entries.at(current_entry));

	//draw mesh
	mesh->render(GL_TRIANGLES, shader);

	g->resource_manager->getShader("menu")->disable();

}

void Menu::update(float dt) {

	Game* g = Game::instance;


}
