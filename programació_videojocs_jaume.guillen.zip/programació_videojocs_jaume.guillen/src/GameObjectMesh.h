#pragma once

#include "GameObject.h"
#include "mesh.h"
#include "texture.h"
#include "shader.h"

class GameObjectMesh : public GameObject {
public:
	Mesh* mesh;
	Texture* texture;
	Shader* shader;
	CollisionModel3D* collision_model;

	void render();
	void update(float dt);
	void clear();
	void addChild(GameObject* obj);
	void removeChild(GameObject* obj);
	void setCollisionModel();
	void bulletCollision();

	Matrix44 getGlobalMatrix();
};