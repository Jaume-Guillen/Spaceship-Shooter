#include "GameObjectHomingShip.h"
#include "game.h"

GameObjectHomingShip::GameObjectHomingShip() {

	Game* game = Game::instance;
	std::vector<GameObject*> players;
	game->scene->findPlayer(players, game->scene->root);
	p = (GameObjectMesh*)players.at(0);

}

void GameObjectHomingShip::update(float dt) {
	
	Vector3 direction = Vector3(p->model.m[12] - this->model.m[12], p->model.m[13] - this->model.m[13], p->model.m[14] - this->model.m[14]).normalize();
	float angle = acos(direction.dot(this->model.frontVector()));
	Vector3 axis = direction.cross(this->model.frontVector());
	Matrix44 inv = this->model;
	inv.inverse();
	Vector3 rot_axis = inv.rotateVector(axis);
	this->model.rotateLocal(-0.01, rot_axis);
	this->model.traslate(direction.x * 30 * dt, direction.y * 30 * dt, direction.z * 30 * dt);

}