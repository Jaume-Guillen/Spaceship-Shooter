#include "GameObjectEnvironment.h"
#include "game.h"
#include <algorithm>

void GameObjectEnvironment::render()
{
	Game* g = Game::instance;
	glDisable(GL_DEPTH_TEST);
	glCullFace(GL_FRONT);
	//crear MVP
	Matrix44 mvp = this->getGlobalMatrix() * g->scene->camera->viewprojection_matrix;
	//crear normal matrix

	//crear una luz temporary

	//subir uniforms al shader

	shader->enable();
	shader->setMatrix44("u_model", model);
	shader->setMatrix44("u_mvp", mvp);
	shader->setUniform3("u_cam_pos", g->scene->camera->eye.x, g->scene->camera->eye.y, g->scene->camera->eye.z);
	shader->setTexture("u_texture_diffuse", texture);

	//draw mesh
	mesh->render(GL_TRIANGLES, shader);
	glEnable(GL_DEPTH_TEST);
	glCullFace(GL_BACK);
	shader->disable();

	for (int i = 0; i < this->children.size(); i++) {
		this->children[i]->render();
	}
}

void GameObjectEnvironment::update(float dt)
{
	Game* g = Game::instance;
	model.setTranslation(g->scene->camera->eye.x, g->scene->camera->eye.y, g->scene->camera->eye.z);
}

void GameObjectEnvironment::clear() {
	delete this;
}

void GameObjectEnvironment::addChild(GameObject* obj)
{
	obj->parent = this;
	this->children.push_back(obj);
}

void GameObjectEnvironment::removeChild(GameObject* obj)
{
	std::vector<GameObject*>::iterator i = std::remove(this->children.begin(), this->children.end(), obj);
	this->children.erase(i, this->children.end());
	delete(obj);
}

Matrix44 GameObjectEnvironment::getGlobalMatrix()
{
	if (this->parent)
		return this->parent->getGlobalMatrix() * this->model;
	else
		return this->model;
}
