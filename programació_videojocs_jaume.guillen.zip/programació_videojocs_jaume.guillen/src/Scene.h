#pragma once
#include "GameObject.h"
#include "Camera.h"
class Scene
{
public:
	Scene();
	~Scene();

	GameObject* root;

	Camera* camera;
	
	void render();
	void update(float);
	void getColliders(std::vector<GameObject*>& colliders, GameObject* current);
	void getAllEnemies(std::vector<GameObject*>& enemies, GameObject* current);
	void findPlayer(std::vector<GameObject*>& enemies, GameObject* current);

};