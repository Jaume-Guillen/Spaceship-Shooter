#pragma once

#include "GameObjectMesh.h"
#include "game.h"
class GameObjectPlayer : public GameObjectMesh{

public:
	Game* game;
	int pitch_speed;
	int vidas;
	GameObjectPlayer();
	void update(float dt);

};