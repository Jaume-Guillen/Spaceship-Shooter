#pragma once
#include "includes.h"
#include "framework.h"

class GameObject {
public:

	std::string name;
	std::string type;
	Matrix44 model;
	bool is_collider = false;

	GameObject* parent = nullptr;
	std::vector<GameObject*> children;

	virtual void render();
	virtual void update(float elapsed_time);
	void clear();
	void addChild(GameObject* obj);
	void removeChild(GameObject* obj);
	void getColliders(std::vector<GameObject*>& colliders, GameObject* current);

	Matrix44 getGlobalMatrix();

};