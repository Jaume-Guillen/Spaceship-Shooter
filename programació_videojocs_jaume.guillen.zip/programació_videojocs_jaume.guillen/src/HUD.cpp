#include "HUD.h"
#include "game.h"
#include "camera.h"
#include "GameObjectPlayer.h"


HUD::HUD(int sw1, int sh1) {

	sw = sw1;
	sh = sh1;
	cam = new Camera();
	cam->setOrthographic(0, sw, 0, sh, 0.1, 2);
	cam->updateViewMatrix();

	minimap_back_mesh = new Mesh();
	minimap_back_mesh->vertices.resize(4);
	minimap_back_mesh->uvs.resize(4);

	minimap_back_mesh->vertices[0] = Vector3(sw-200, 0, 1); minimap_back_mesh->uvs[0] = Vector2(0, 0);
	minimap_back_mesh->vertices[1] = Vector3(sw, 0, 1); minimap_back_mesh->uvs[1] = Vector2(1, 0);
	minimap_back_mesh->vertices[2] = Vector3(sw, 200, 1); minimap_back_mesh->uvs[2] = Vector2(1, 1);
	minimap_back_mesh->vertices[3] = Vector3(sw-200, 200, 1); minimap_back_mesh->uvs[3] = Vector2(0, 1);

	minimap_back_mesh->indices.resize(6);
	minimap_back_mesh->indices[0] = 0; minimap_back_mesh->indices[1] = 1; minimap_back_mesh->indices[2] = 2;
	minimap_back_mesh->indices[3] = 0; minimap_back_mesh->indices[4] = 2; minimap_back_mesh->indices[5] = 3;

	minimap_back_mesh->genBuffers();

	healthbar = new Mesh();
	healthbar->vertices.resize(4);
	healthbar->uvs.resize(4);

	healthbar->vertices[0] = Vector3(300, 50, 1); healthbar->uvs[0] = Vector2(0, 0);
	healthbar->vertices[1] = Vector3(500, 50, 1); healthbar->uvs[1] = Vector2(1, 0);
	healthbar->vertices[2] = Vector3(500, 100, 1); healthbar->uvs[2] = Vector2(1, 1);
	healthbar->vertices[3] = Vector3(300, 100, 1); healthbar->uvs[3] = Vector2(0, 1);

	healthbar->indices.resize(6);
	healthbar->indices[0] = 0; healthbar->indices[1] = 1; healthbar->indices[2] = 2;
	healthbar->indices[3] = 0; healthbar->indices[4] = 2; healthbar->indices[5] = 3;

	healthbar->genBuffers();

	tex_shader = new Shader();
	tex_shader->load("data/shaders/screen.vert", "data/shaders/screen.frag");
	minimap_back_texture = new Texture();
	minimap_back_texture->load("data/assets/healthbar.tga");
}

void HUD::render()
{

	glDisable(GL_DEPTH_TEST);
	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

	tex_shader->enable();
	tex_shader->setTexture("u_texture_diffuse", minimap_back_texture);
	tex_shader->setMatrix44("u_mvp", cam->viewprojection_matrix);
	//minimap_back_mesh->render(GL_TRIANGLES, tex_shader);

	Game* g = Game::instance;
	std::vector<GameObject*> players;
	g->scene->findPlayer(players, g->scene->root);
	GameObjectMesh* pl = (GameObjectMesh*)players.at(0);
	GameObjectPlayer* p = (GameObjectPlayer*)pl;

	healthbar->vertices[0] = Vector3(300, 50, 1); healthbar->uvs[0] = Vector2(0, 0);
	healthbar->vertices[1] = Vector3(300 + p->vidas*40, 50, 1); healthbar->uvs[1] = Vector2(1, 0);
	healthbar->vertices[2] = Vector3(300 + p->vidas*40, 100, 1); healthbar->uvs[2] = Vector2(1, 1);
	healthbar->vertices[3] = Vector3(300, 100, 1); healthbar->uvs[3] = Vector2(0, 1);

	healthbar->indices.resize(6);
	healthbar->indices[0] = 0; healthbar->indices[1] = 1; healthbar->indices[2] = 2;
	healthbar->indices[3] = 0; healthbar->indices[4] = 2; healthbar->indices[5] = 3;

	healthbar->genBuffers();

	healthbar->render(GL_TRIANGLES, tex_shader);
	
	GLfloat healthbarVertices[] =
	{

		300 ,100, 1,
		300, 25, 1,
		500, 100, 1,
		500, 25, 1

	};

	GLfloat colour[] =
	{
		0, 255, 0,
		0, 255, 0,
		0, 255, 0,
		0, 255, 0
	};

	glPointSize(7.0f);
	Mesh* pointsMesh = new Mesh();
	pointsMesh->vertices.resize(points.size() + 1);
	pointsMesh->indices.resize(points.size() + 1);

	for (int i = 0; i < points.size(); i++) {
		pointsMesh->vertices[i] = points.at(i);
		pointsMesh->indices[i] = i;
	}

	pointsMesh->vertices[points.size()] = Vector3(sw-100, 100, 1);
	pointsMesh->indices[points.size()] = points.size();

	pointsMesh->genBuffers();
	pointsMesh->render(GL_POINTS, tex_shader);

	tex_shader->disable();

	glEnable(GL_DEPTH_TEST);

}

void HUD::update(float)
{

	Game* g = Game::instance;

	std::vector<GameObject*> enemies;

	g->scene->getAllEnemies(enemies, g->scene->root);

	points.clear();

	for (int i = 0; i < enemies.size(); i++) {

		std::vector<GameObject*> players;
		g->scene->findPlayer(players, g->scene->root);
		GameObjectMesh* pl = (GameObjectMesh*)players.at(0);

		Vector3 f = pl->model.frontVector();
		f.y = 0;
		f.z = -f.z;

		Vector3 p = Vector3(pl->model.m[12], pl->model.m[13], pl->model.m[14]);
		Vector3 pe = Vector3(enemies.at(i)->model.m[12], enemies.at(i)->model.m[13], enemies.at(i)->model.m[14]) - p;

		float angle = acos(f.dot(pe));

		float enemy_dist = pe.length();
		
		Vector3 xp;

		xp.x = f.y * pe.z - f.z * pe.y;
		xp.y = f.x * pe.z - f.z * pe.x;
		xp.z = f.x * pe.y - f.y * pe.x;

		if (xp.y > 0) {

			angle = -angle;

		}

		float max_distance = 200;

		float minimap_radius = 100;

		float radius = (minimap_radius / max_distance) * enemy_dist;

		Vector3 c = Vector3(sw - 100, 100, 1);

		points.push_back(Vector3(c.x + radius * sin(angle), c.y + radius * cos(angle), 1));

	}

}
