#include "ResourceManager.h"

ResourceManager :: ResourceManager() {

	cout << "We made a resource manager. Whoo. Hoo\n";

}

ResourceManager :: ~ResourceManager() {

	cout << "Resource manager destroyed.\n";

}

void ResourceManager::loadMesh(const string handle, const string path)
{
	Mesh* mesh = new Mesh();
	mesh->loadASE(path.c_str());

	m_meshes[handle] = mesh;
}

Mesh* ResourceManager::getMesh(const string handle) {

	return m_meshes[handle];

}

void ResourceManager::unloadMesh(const string handle)
{
	unordered_map<string, Mesh*>::iterator itr = m_meshes.find(handle);

	if (itr != m_meshes.end()) {

		delete itr->second;
		m_meshes.erase(itr);
	}
	else
	{
	cout << "could not find asset with handle" << handle << endl;
	exit(0);

	}
}

void ResourceManager::loadShader(const string pathVert, const string pathFrag, const string handle)
{
	Shader* shader = new Shader();
	if (!shader->load(pathVert, pathFrag)) {
		std::cout << "Error, no es pot carregar el Shader!";
		exit(0);
	}
	m_shaders[handle] = shader;
}

Shader* ResourceManager::getShader(const string handle) {

	return m_shaders[handle];

}

void ResourceManager::unloadShader(const string handle)
{
	unordered_map<string, Shader*>::iterator itr = m_shaders.find(handle);

	if (itr != m_shaders.end()) {

		delete itr->second;
		m_shaders.erase(itr);
	}
	else
	{
		cout << "could not find asset with handle" << handle << endl;
		exit(0);

	}
}

void ResourceManager::loadTexture(const string handle, const string path)
{
	Texture* texture = new Texture();
	texture->load(path.c_str());
	m_textures[handle] = texture;

}

Texture* ResourceManager::getTexture(const string handle)
{
	return m_textures[handle];
}

void ResourceManager::unloadTexture(const string handle)
{
	unordered_map<string, Texture*>::iterator itr = m_textures.find(handle);

	if (itr != m_textures.end()) {

		delete itr->second;
		m_textures.erase(itr);
	}
	else
	{
		cout << "could not find asset with handle" << handle << endl;
		exit(0);

	}
}
