#include "GameObjectEnemy.h"

void GameObjectEnemy::SetOriginalPos()
{
	original_position = new Vector3(this->model.m[12], this->model.m[13], this->model.m[14]);
}

void GameObjectEnemy::update(float dt)
{
	std::cout << "Update enemy with dt " << dt << "\n";

	Vector3 new_position = Vector3(this->model.m[12], this->model.m[13], this->model.m[14]);
	
	
	Vector3 to_target = (waypoints[i] - new_position).normalize();
	//float pepe = to_target.dot(this->model.frontVector());
	float angle = acos(to_target.dot(this->model.frontVector()));
	Vector3 axis = to_target.cross(this->model.frontVector());
	Matrix44 inv = this->model;
	inv.inverse();
	Vector3 rot_axis = inv.rotateVector(axis);
	this->model.rotateLocal(-0.01, rot_axis);
	std::cout << "angle" << angle << "\n";
	
	if (angle > 3) {
		Vector3 onVullAnar = waypoints[i] - new_position;
		std::cout << "dist" << onVullAnar.length() << "\n";

		std::cout << "i: " << i << "\n";
		if (onVullAnar.length() < 1) {

			i++;
			if (i == waypoints.size()) {
				i = 0;
			}

		}
		Vector3 onAnem = onVullAnar.normalize();
		this->model.traslate(onAnem.x * 10 * dt, onAnem.y * 10 * dt, onAnem.z * -10 * dt);
	}

}


void GameObjectEnemy::afegirWaypoint(float x, float y, float z)
{
	waypoints.push_back(Vector3(x, y, z));

}

