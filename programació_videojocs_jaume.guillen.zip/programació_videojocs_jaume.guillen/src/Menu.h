#pragma once
#include "mesh.h"
#include "texture.h"
class Menu
{

public:
	Menu();
	~Menu();

	Mesh* mesh;

	std::vector<Texture*> entries;
	int current_entry;
	Shader* shader;

	void render();
	void update(float);
};