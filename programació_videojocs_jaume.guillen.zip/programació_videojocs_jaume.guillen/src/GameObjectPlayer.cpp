#include "GameObjectPlayer.h"
#include "game.h"


GameObjectPlayer::GameObjectPlayer()
{
	game = Game::instance;
	pitch_speed = 5;
	vidas = 5;
}
void GameObjectPlayer::update(float dt) {

	if (vidas > 0) {

		if (game->keystate[SDL_SCANCODE_W] || game->keystate[SDL_SCANCODE_UP]) {

			this->model.rotateLocal(dt * pitch_speed, Vector3(1, 0, 0));

		}

		if (game->keystate[SDL_SCANCODE_S] || game->keystate[SDL_SCANCODE_DOWN]) {

			this->model.rotateLocal(-dt * pitch_speed, Vector3(1, 0, 0));

		}

		if (game->keystate[SDL_SCANCODE_A] || game->keystate[SDL_SCANCODE_LEFT]) {

			this->model.rotateLocal(-dt * pitch_speed, Vector3(0, 0, 1));

		}

		if (game->keystate[SDL_SCANCODE_D] || game->keystate[SDL_SCANCODE_RIGHT]) {

			this->model.rotateLocal(dt * pitch_speed, Vector3(0, 0, 1));

		}

		Vector3 f = this->model.frontVector().normalize();

		if (game->keystate[SDL_SCANCODE_SPACE]) {

			float bullet_speed = 400;
			game->bm->createBullet(Vector3(this->model.m[12], this->model.m[13], this->model.m[14]), Vector3(-f.x * bullet_speed, -f.y * bullet_speed, -f.z * bullet_speed), 600, 2, this);

		}


		float speed_dt = dt * 10;
		Vector3 direction = Vector3(f.x * speed_dt, f.y * speed_dt, f.z * speed_dt);
		this->model.traslate(-f.x*speed_dt, -f.y * speed_dt, -f.z * speed_dt);
		//game->scene->camera->eye = game->scene->camera->eye.lerp(Vector3(this->model.m[12], this->model.m[13] + 20, this->model.m[14] + 40), 0.5);
		game->scene->camera->eye = Vector3(this->model.m[12], this->model.m[13], this->model.m[14]) + f * 30 + (Vector3(this->model.m[4], this->model.m[5], this->model.m[6]).normalize()) * 5;
		Vector3 posicioCenter = Vector3(this->model.m[12], this->model.m[13], this->model.m[14]) + f * 5;
		game->scene->camera->center = game->scene->camera->center.lerp(posicioCenter, 0.5);
		//game->scene->camera->up = game->scene->camera->up.lerp(Vector3(this->model.m[4], this->model.m[5], this->model.m[6]), 0.1);
		game->scene->camera->up = Vector3(this->model.m[4], this->model.m[5], this->model.m[6]);

	}


}