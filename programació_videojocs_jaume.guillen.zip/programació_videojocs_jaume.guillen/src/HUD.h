#pragma once
#include "mesh.h"
#include "shader.h"
#include "camera.h"
class HUD
{

public:
	HUD(int, int);
	~HUD();

	Camera* cam;
	Shader* tex_shader;

	Mesh* minimap_back_mesh;
	Texture* minimap_back_texture;

	Mesh* healthbar;
	int sw;
	int sh;
	int current_entry;
	Shader* shader;
	std::vector<Vector3> points;

	void render();
	void update(float);
};