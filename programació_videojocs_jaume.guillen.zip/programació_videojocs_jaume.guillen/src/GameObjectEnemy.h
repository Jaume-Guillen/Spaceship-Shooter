#pragma once
#include "GameObjectMesh.h"
class GameObjectEnemy : public GameObjectMesh {

public:
	std::vector<Vector3> waypoints;
	Vector3* original_position;
	int i;
	void SetOriginalPos();
	void update(float dt);
	void afegirWaypoint(float x, float y, float z);

};