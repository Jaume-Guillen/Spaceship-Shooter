#include "GameObject.h"
#include "Scene.h"

Scene::Scene()
{
	this->root = new GameObject();
	camera = new Camera();
}

Scene::~Scene()
{
	this->root->clear();
	delete this->root;
}

void Scene::render()
{
	camera->set();
	this->root->render();
}

void Scene::update(float dt)
{
	this->root->update(dt);
}

void Scene::getColliders(std::vector<GameObject*>& colliders, GameObject* current)
{

	if (current->is_collider) {

		colliders.push_back(current);

	}

	for (int i = 0; i < current->children.size(); i++) {

		getColliders(colliders, current->children[i]);

	}

}

void Scene::getAllEnemies(std::vector<GameObject*>& enemies, GameObject * current)
{

	if (current->type == "Enemy") {

		enemies.push_back(current);

	}

	for (size_t i = 0; i < current->children.size(); i++) {

		getAllEnemies(enemies, current->children[i]);

	}

}

void Scene::findPlayer(std::vector<GameObject*>& players, GameObject * current)
{

	if (current->type == "Player") {

		players.push_back(current);

	}

	for (size_t i = 0; i < current->children.size(); i++) {

		findPlayer(players, current->children[i]);

	}

}

