#include "ShipGen.h"
#include"GameObjectHomingShip.h"
#include "game.h"
#include"GameObjectPlayer.h"
#define PI 3.14159265
ShipGen::ShipGen()
{
	
	maxTime = 5;
	time = maxTime;
}

void ShipGen::update(float dt)
{
	Game* g;
	g = Game::instance;
	if (time <= 0) {

		std::vector<GameObject*> players;
		g->scene->findPlayer(players, g->scene->root);
		GameObjectMesh* p = (GameObjectMesh*)players.at(0);
		GameObjectPlayer* pl = (GameObjectPlayer*)p;

		if (pl->vidas > 0) {

			GameObjectMesh* homingShip = new GameObjectHomingShip();
			homingShip->mesh = g->resource_manager->getMesh("x3_fighter");
			homingShip->shader = g->resource_manager->getShader("basic");
			homingShip->texture = g->resource_manager->getTexture("x3_fighter");
			g->gameObjectMeshes.push_back(*homingShip);
			homingShip->setCollisionModel();
			homingShip->name = "X3_fighter_enemy2";
			homingShip->model.traslate(cos(rand() % 360 * PI / 180.0) * 200 + p->model.m[12], sin(rand() % 360 * PI / 180.0) * 200 + p->model.m[13], p->model.m[14]);
			homingShip->type = "Enemy";

			g->scene->root->addChild(homingShip);

			//scene->camera->move(Vector3(0, 0, 50));
			g->scene->getColliders(g->colliders, homingShip);

		}

		time = maxTime;

	}
	else {

		time = time - dt;
		
	}
}
