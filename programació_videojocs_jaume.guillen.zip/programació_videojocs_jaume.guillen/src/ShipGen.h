#pragma once
class ShipGen{

public:
	ShipGen();
	
	
	void update(float dt);
	float maxTime;
	float time;

};