#include "GameObject.h"
#include <algorithm>
#include "game.h"
#include "shader.h"
#include "mesh.h"
void GameObject::render()
{
	//std::cout << "Render mesh with name root\n";
	Game* g = Game::instance;
	//crear MVP
	Matrix44 mvp = this->getGlobalMatrix() * g->scene->camera->viewprojection_matrix;
	
	for (int i = 0; i < this->children.size(); i++) {
		this->children[i]->render();

		std::cout << i << "\n";
	}
}

void GameObject::update(float elapsed_time)
{
	for (int i = 0; i < this->children.size(); i++) {
		this->children[i]->update(elapsed_time);

		std::cout << i << "\n";
	}
}

void GameObject::clear() {
	removeChild(this);

	for (int i = 0; i < parent->children.size(); i++) {

		if (parent->children.at(i)->name.compare(this->name) == 0) {
			parent->children.erase(parent->children.begin() + i);
			Game* g = Game::instance;
			for (int j = 0; j < g->colliders.size(); j++) {

				if (g->colliders[j]->name.compare(this->name) == 0) {
					g->colliders.erase(g->colliders.begin() + j);
					//g->colliders[j] = NULL;
					break;

				}

			}
			break;

		}

	}

	parent = NULL;
	delete(this);
}

void GameObject::addChild(GameObject* obj)
{
	obj->parent = this;
	this->children.push_back(obj);
}

void GameObject::removeChild(GameObject* obj)
{
	std::vector<GameObject*>::iterator i = std::remove(this->children.begin(), this->children.end(), obj);
	this->children.erase(i, this->children.end());
	delete(obj);
}

void GameObject::getColliders(std::vector<GameObject*>& colliders, GameObject* current)
{
}

Matrix44 GameObject::getGlobalMatrix()
{
	return model;
}




