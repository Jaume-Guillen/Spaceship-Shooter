#include "game.h"
#include "utils.h"
#include "mesh.h"
#include "texture.h"
#include "rendertotexture.h"
#include "shader.h"
#include <vector>
#include "GameObjectEnemy.h"
#include "GameObjectPlayer.h"
#include "BulletManager.h"
#include "GameObjectHomingShip.h"

#include <cmath>

//some globals
float angle = 0;
RenderToTexture* rt = NULL;

GameObjectEnvironment* temp_game_object_mesh2;


Game* Game::instance = NULL;

Game::Game(SDL_Window* window)
{
	this->window = window;
	instance = this;

	// initialize attributes
	// Warning: DO NOT CREATE STUFF HERE, USE THE INIT 
	// things create here cannot access opengl
	SDL_GetWindowSize( window, &window_width, &window_height );
	std::cout << " * Window size: " << window_width << " x " << window_height << std::endl;

	keystate = NULL;
	mouse_locked = false;

	
}

//Here we have already GL working, so we can create meshes and textures
void Game::init(void)
{
    std::cout << " * Path: " << getPath() << std::endl;
	sg = ShipGen();
    //SDL_SetWindowSize(window, 50,50);

	hud = new HUD(800, 600);
	
	resource_manager = new ResourceManager();
	scene = new Scene();
	//OpenGL flags
	glEnable( GL_CULL_FACE ); //render both sides of every triangle
	glEnable( GL_DEPTH_TEST ); //check the occlusions using the Z buffer
	//create our camera
	scene->camera->lookAt(Vector3(0,25,25),Vector3(0,0,0), Vector3(0,1,0)); //position the camera and point to 0,0,0
	scene->camera->setPerspective(70.0f,(float)window_width/(float)window_height,0.1f,10000.0f); //set the projection, we want to be perspective

	//create a plane mesh
	//mesh = new Mesh();
	//mesh->createPlane(10);
	//mesh->loadASE("data/assets/x3_fighter.ASE");

	
	resource_manager->loadMesh("x3_fighter", "data/assets/x3_fighter.ASE");
	resource_manager->loadMesh("skybox", "data/assets/sphere.ASE");
	resource_manager->loadMesh("bullet", "data/assets/bullet.ASE");
	bm = new BulletManager(resource_manager->getMesh("bullet"), 20);

	//texture = new Texture();
	//texture->load("data/assets/x3_fighter.tga");

	resource_manager->loadTexture("x3_fighter", "data/assets/x3_fighter.tga");
	resource_manager->loadTexture("skybox", "data/assets/milkyway.tga");

	//shader = new Shader();
	resource_manager->loadShader("data/shaders/simple.vert", "data/shaders/simple.frag", "basic");
	resource_manager->loadShader("data/shaders/menu.vert", "data/shaders/menu.frag", "menu");
	resource_manager->loadShader("data/shaders/simple_texture_only.vert", "data/shaders/simple_texture_only.frag", "skybox");

	//if( !shader->load("data/shaders/simple.vert","data/shaders/simple.frag") )
	//{
		//std::cout << "shader not found or error" << std::endl;
		//if your program quits straight after opening, the shader probably hasn't compiled,
		//if you put a breakpoint here you'll be able to read the compilation error in the console
		//exit(0);
	//}

	//hide the cursor
	SDL_ShowCursor(!mouse_locked); //hide or show the mouse
	GameObjectMesh* fighter = new GameObjectMesh();
	fighter->mesh = resource_manager->getMesh("x3_fighter");
	fighter->shader = resource_manager->getShader("basic");
	fighter->texture = resource_manager->getTexture("x3_fighter");
	gameObjectMeshes.push_back(*fighter);
	fighter->setCollisionModel();
	fighter->name = "X3_fighter normal";

	GameObjectEnemy* fighter2 = new GameObjectEnemy();
	fighter2->mesh = resource_manager->getMesh("x3_fighter");
	fighter2->shader = resource_manager->getShader("basic");
	fighter2->texture = resource_manager->getTexture("x3_fighter");
	gameObjectMeshes.push_back(*fighter2);
	fighter2->setCollisionModel();
	fighter2->name = "X3_fighter_enemy";

	GameObjectMesh* fighter3 = new GameObjectPlayer();
	fighter3->mesh = resource_manager->getMesh("x3_fighter");
	fighter3->shader = resource_manager->getShader("basic");
	fighter3->texture = resource_manager->getTexture("x3_fighter");
	gameObjectMeshes.push_back(*fighter3);
	fighter3->setCollisionModel();
	fighter3->name = "X3_fighter player";

	GameObjectEnvironment* skybox = new GameObjectEnvironment();
	skybox->mesh = resource_manager->getMesh("skybox");
	skybox->shader = resource_manager->getShader("skybox");
	skybox->texture = resource_manager->getTexture("skybox");
	//gameObjectMeshes.push_back(*temp_game_object_mesh2);

	
	
	scene->root->addChild(skybox);
	//scene->root->addChild(fighter);
	scene->root->addChild(fighter3);
	

	fighter2->type = "Enemy";
	fighter->model.traslate(30, 0, 0);
	fighter->addChild(fighter2);
	fighter2->model.traslate(0, 40, 0);
	fighter2->SetOriginalPos();
	fighter2->afegirWaypoint(-50, 0, 0);
	fighter2->afegirWaypoint(50, 0, 0);
	fighter3->model.traslate(0, 0, 0);
	fighter3->type = "Player";

	GameObjectMesh* fighter4 = new GameObjectHomingShip();
	fighter4->mesh = resource_manager->getMesh("x3_fighter");
	fighter4->shader = resource_manager->getShader("basic");
	fighter4->texture = resource_manager->getTexture("x3_fighter");
	gameObjectMeshes.push_back(*fighter4);
	fighter4->setCollisionModel();
	fighter4->name = "X3_fighter_enemy2";
	fighter4->model.traslate(-20, 0, 0);
	fighter4->type = "Enemy";

	//scene->root->addChild(fighter4);
	
	//scene->camera->move(Vector3(0, 0, 50));
	this->scene->getColliders(colliders, scene->root);

}

//what to do when the image has to be draw
void Game::render(void)
{
	//set the clear color (the background color)
	glClearColor(0.0, 0.0, 0.0, 1.0);

	// Clear the window and the depth buffer
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	//update view and projection matrices, and push gl matrices for fixed pipeline rendering

	//camera->set();

	//temp_game_object_mesh2->render();
	for (int i = 0; i < gameObjectMeshes.size(); i++) {

		//gameObjectMeshes.at(i).render();

	}
	scene->render();
	bm->render();
	
	//*** Drawing code starts here ***
   
	//create model matrix for our plane mesh
	//Matrix44 m;
 //   m.setScale(1,1,1);
	////build a rotation matrix - angle is incremented in update()
	//m.rotate(angle * DEG2RAD, Vector3(0,1,0) ); 

	////create our mvp
	//Matrix44 mvp = m * camera->viewprojection_matrix;
	//
	////enable shader and set uniforms
	//resource_manager->getShader("basic")->enable();
	//resource_manager->getShader("basic")->setMatrix44("u_model", m );
	//resource_manager->getShader("basic")->setMatrix44("u_mvp", mvp );
	//resource_manager->getShader("basic")->setUniform3("u_cam_pos", camera->eye.x, camera->eye.y, camera->eye.z);
	//resource_manager->getShader("basic")->setTexture("u_texture_diffuse", resource_manager->getTexture("x3_fighter"));
 //  
	////call render function for mesh, passing shader as param
	////mesh->render() binds the relevant attributes, and drawing code
	////mesh->render(GL_TRIANGLES, shader);
	//resource_manager->getMesh("x3_fighter")->render(GL_TRIANGLES, resource_manager->getShader("basic"));
	//
	////disable the shader
	//resource_manager->getShader("basic")->disable();
	//
	////disable blending to draw text on top
 //   glDisable( GL_BLEND );

	//*** Drawing code ends here ***
	hud->render();
	//swap between front buffer and back buffer
	SDL_GL_SwapWindow(this->window);
}

void Game::update(double seconds_elapsed)
{
	double speed = seconds_elapsed * 100; //the speed is defined by the seconds_elapsed so it goes constant

	//mouse input to rotate the cam
	if ((mouse_state & SDL_BUTTON_LEFT) || mouse_locked ) //is left button pressed?
	{
		scene->camera->rotate(mouse_delta.x * 0.005f, Vector3(0,-1,0));
		scene->camera->rotate(mouse_delta.y * 0.005f, scene->camera->getLocalVector( Vector3(-1,0,0)));
	}

	//async input to move the camera around
	//if(keystate[SDL_SCANCODE_LSHIFT]) speed *= 10; //move faster with left shift
	//if (keystate[SDL_SCANCODE_W] || keystate[SDL_SCANCODE_UP]) scene->camera->move(Vector3(0,0,1) * (float)speed);
	//if (keystate[SDL_SCANCODE_S] || keystate[SDL_SCANCODE_DOWN]) scene->camera->move(Vector3(0,0,-1) * (float)speed);
	//if (keystate[SDL_SCANCODE_A] || keystate[SDL_SCANCODE_LEFT]) scene->camera->move(Vector3(1,0,0) * (float)speed);
	//if (keystate[SDL_SCANCODE_D] || keystate[SDL_SCANCODE_RIGHT]) scene->camera->move(Vector3(-1,0,0) * (float)speed);
	bm->update(seconds_elapsed);
	//to navigate with the mouse fixed in the middle
	if (mouse_locked)
	{
		int center_x = (int)floor(window_width*0.5f);
		int center_y = (int)floor(window_height*0.5f);
        //center_x = center_y = 50;
		SDL_WarpMouseInWindow(this->window, center_x, center_y); //put the mouse back in the middle of the screen
		//SDL_WarpMouseGlobal(center_x, center_y); //put the mouse back in the middle of the screen
        
        this->mouse_position.x = (float)center_x;
        this->mouse_position.y = (float)center_y;
	}

	hud->update(seconds_elapsed);
	sg.update(seconds_elapsed);
    
	scene->root->update(seconds_elapsed);

	//std::vector<GameObject*> colliders;
	
	

	for (int i = 0; i < colliders.size(); i++) {

		for (int j = i + 1; j < colliders.size(); j++) {

			if (colliders[i] == NULL || colliders[j] == NULL) {

				break;

			}

			GameObjectMesh* A = dynamic_cast<GameObjectMesh*> (colliders[i]);
			GameObjectMesh* B = dynamic_cast<GameObjectMesh*> (colliders[j]);
			A->collision_model->setTransform(A->model.m);
			B->collision_model->setTransform(B->model.m);

			bool collision = A->collision_model->collision(B->collision_model);

			if (collision) {

				std::cout << "Colisio entre" << colliders[i]->name << " i " << colliders[j]->name << "\n";

				if (colliders[i]->type == "Player" && colliders[j]->type == "Enemy") {

					GameObjectMesh* aux = (GameObjectMesh*)colliders[j];
					aux->clear();
					GameObjectPlayer* auxp = (GameObjectPlayer*)colliders[i];
					auxp->vidas -= 1;

					if (auxp->vidas <= 0) {


					}

				}

			}

		}

	}

	angle += (float)seconds_elapsed * 10;
}

//Keyboard event handler (sync input)
void Game::onKeyPressed( SDL_KeyboardEvent event )
{
	switch(event.keysym.sym)
	{
		case SDLK_ESCAPE: exit(0); //ESC key, kill the app
	}
}


void Game::onMouseButton( SDL_MouseButtonEvent event )
{
	if (event.button == SDL_BUTTON_MIDDLE) //middle mouse
	{
		mouse_locked = !mouse_locked;
		SDL_ShowCursor(!mouse_locked);
	}
}

void Game::setWindowSize(int width, int height)
{
    std::cout << "window resized: " << width << "," << height << std::endl;
    
	/*
    Uint32 flags = SDL_GetWindowFlags(window);
    if(flags & SDL_WINDOW_ALLOW_HIGHDPI)
    {
        width *= 2;
        height *= 2;
    }
	*/

	glViewport( 0,0, width, height );
	scene->camera->aspect =  width / (float)height;
	window_width = width;
	window_height = height;
}

