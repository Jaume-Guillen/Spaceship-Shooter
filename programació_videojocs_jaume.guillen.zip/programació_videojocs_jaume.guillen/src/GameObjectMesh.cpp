#include "GameObjectMesh.h"
#include "game.h"
#include "GameObjectPlayer.h"
#include <algorithm>

void GameObjectMesh::render() {

	//std::cout << "Render mesh with name " << name << "\n";

	Game* g = Game::instance;

	//crear MVP
	Matrix44 mvp = this->getGlobalMatrix() * g->scene->camera->viewprojection_matrix;
	//crear normal matrix

	//crear una luz temporary

	//subir uniforms al shader

	shader->enable();
	shader->setMatrix44("u_model", model );
	shader->setMatrix44("u_mvp", mvp );
	shader->setUniform3("u_cam_pos", g->scene->camera->eye.x, g->scene->camera->eye.y, g->scene->camera->eye.z);
	shader->setTexture("u_texture_diffuse", texture);

	//draw mesh
	if (type != "Player") {
		mesh->render(GL_TRIANGLES, shader);
	}
	if (type == "Player") {

		GameObjectPlayer* aux = (GameObjectPlayer*)this;

		if (aux->vidas > 0) {

			mesh->render(GL_TRIANGLES, shader);

		}

	}

	shader->disable();

	for (int i = 0; i < this->children.size(); i++) {
		this->children[i]->render();
	}
}

void GameObjectMesh::update(float dt)
{

	
	
	std::cout <<"Update with dt "<< dt << "\n";
	for (int i = 0; i < this->children.size(); i++) {
		this->children[i]->update(dt);

		std::cout << i << "\n";
	}


}

void GameObjectMesh::clear() {
	removeChild(this);
	
	for (int i = 0; i < parent->children.size(); i++) {

		if (parent->children.at(i)->name.compare(this->name) == 0) {
			parent->children.erase(parent->children.begin() + i);
			Game* g = Game::instance; 
			for (int j = 0; j < g->colliders.size(); j++) {

				if (g->colliders[j]->name.compare(this->name) == 0) {
					g->colliders.erase(g->colliders.begin() + j);
					//g->colliders[j] = NULL;
					break;

				}

			}
			break;

		}

	}

	parent = NULL;
	mesh = NULL;
	delete(this);
	
}

void GameObjectMesh::addChild(GameObject* obj)
{
	obj->parent = this;
	this->children.push_back(obj);
}

void GameObjectMesh::removeChild(GameObject* obj)
{
	std::vector<GameObject*>::iterator i = std::remove(this->children.begin(), this->children.end(), obj);
	this->children.erase(i, this->children.end());
	//obj->clear();
}

void GameObjectMesh::setCollisionModel()
{

	collision_model = newCollisionModel3D();

	collision_model->setTriangleNumber(mesh->indices.size() / 3);

	for (int i = 0; i < mesh->indices.size() / 3; i++) {

		Vector3 v1 = mesh->vertices[mesh->indices[i * 3]];
		Vector3 v2 = mesh->vertices[mesh->indices[i * 3 + 1]];
		Vector3 v3 = mesh->vertices[mesh->indices[i * 3 + 2]];

		collision_model->addTriangle(v1.x, v1.y, v1.z, v2.x, v2.y, v2.z, v3.x, v3.y, v3.z);
	}

	collision_model->finalize();
	this->is_collider = true;

}

void GameObjectMesh::bulletCollision()
{
	clear();
}

Matrix44 GameObjectMesh::getGlobalMatrix()
{
	if (this->parent)
		return this->parent->getGlobalMatrix() * this->model;
	else
		return this->model;
}
