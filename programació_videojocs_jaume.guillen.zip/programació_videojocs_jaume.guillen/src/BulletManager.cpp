#include "BulletManager.h"
#include "game.h"

BulletManager::BulletManager(Mesh* theMesh, int max_bullets)
{
	bullet_mesh = theMesh;
	bullets_vector.resize(max_bullets);
}

void BulletManager::render()
{
	Game* g = Game::instance;
	
	

	for (int i = 0; i < bullets_vector.size(); i++) {
		if (bullets_vector.at(i).valid == true) {
			Matrix44 mod;
			mod.traslate(bullets_vector.at(i).position.x, bullets_vector.at(i).position.y, bullets_vector.at(i).position.z);

			Matrix44 mvp = mod * g->scene->camera->viewprojection_matrix;
			g->resource_manager->getShader("basic")->enable();
			g->resource_manager->getShader("basic")->setMatrix44("u_model", mod);
			g->resource_manager->getShader("basic")->setMatrix44("u_mvp", mvp);
			g->resource_manager->getShader("basic")->setUniform3("u_cam_pos", g->scene->camera->eye.x, g->scene->camera->eye.y, g->scene->camera->eye.z);
			bullet_mesh->render(GL_TRIANGLES, shader);

			g->resource_manager->getShader("basic")->disable();
		}

		
	}

}

void BulletManager::update(float elapsed_time)
{
	Game* g = Game::instance;

	for (int i = 0; i < bullets_vector.size(); i++) {
		if (bullets_vector.at(i).valid == true) {
			bullets_vector.at(i).old_position.x = bullets_vector.at(i).position.x;
			bullets_vector.at(i).old_position.y = bullets_vector.at(i).position.y;
			bullets_vector.at(i).old_position.z = bullets_vector.at(i).position.z;
			Matrix44 mod;
			float y = 0;
			bullets_vector.at(i).position = bullets_vector.at(i).position + bullets_vector.at(i).velocity * elapsed_time + Vector3(0, -y, 0) * elapsed_time;
			mod.traslate(bullets_vector.at(i).position.x, bullets_vector.at(i).position.y, bullets_vector.at(i).position.z);
			bullets_vector.at(i).ttl = bullets_vector.at(i).ttl - elapsed_time;

			if (bullets_vector.at(i).ttl < 0) {

				bullets_vector.at(i).valid = false;

			}



		}

		

	}
	checkCollision(g->colliders);

}

void BulletManager::createBullet(Vector3 pos, Vector3 vel, float power, float ttl, GameObject* owner)
{

	Bullet b{ true, pos, pos, vel, ttl, power, owner};
	std::cout << "Bullet position: " << b.velocity.x << ", " << b.velocity.y << ", " << b.velocity.z << "\n";
	for (int i = 0; i < bullets_vector.size(); i++) {

		if (bullets_vector[i].valid == false) {

			bullets_vector.at(i) = b;
			break;

		}

	}

}

void BulletManager::checkCollision(std::vector<GameObject*>& colliders)
{
	std::cout << "Collider size: " << colliders.size();
	for (int i = 0; i < bullets_vector.size(); i++) {

		if (bullets_vector[i].valid == false) {

			continue;

		}

		for (int j = 0; j < colliders.size(); j++) {
			if (bullets_vector[i].owner == colliders[j] || colliders[j] == NULL) {

				continue;

			}

			//std::cout << "Collider: " << colliders[j]->name;

			GameObjectMesh* go = dynamic_cast<GameObjectMesh*>(colliders[j]);
			go->collision_model->setTransform(go->model.m);
			if (go->collision_model->rayCollision(bullets_vector[i].old_position.v, bullets_vector[i].position.v, false, 0, 1)) {

				bullets_vector[i].valid = false;

				Vector3 collision_point;
				go->collision_model->getCollisionPoint(collision_point.v, true);
				go->bulletCollision();
				std::cout << "Tocat!\n";

				continue;

			}

		}

	}

}
