#pragma once

#include "GameObjectEnemy.h"
class GameObjectHomingShip : public GameObjectEnemy {

public:

	GameObjectHomingShip();
	void update(float dt);

	GameObjectMesh* findPlayer();
	GameObjectMesh* p;

};