Jaume Guillen Picola: jaume.guillen
Moviment amb ASWD. Es dispara amb espai. Dispara a les naus que et persegueixen per destruir-les. Si et disparen 5 cops, estàs mort!